#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include <unistd.h> 
#include <sys/wait.h>
#include <malloc.h>
// kernel start location
// if there is no KASLR
#define PHYS_OFFSET 0xFFFF880000000000ul

int main()
{
    int childpid;

    uint32_t * probe_array = (uint32_t *) memalign(4096, 256 * 1024 * sizeof(uint32_t));
    
    // memset the whole array
    // fill with 0's
    //memset(probe_array, 0, 256 * 1024 * sizeof(uint32_t));
    
    for(int i = 0; i < 256 * 1024; i++){
        probe_array[i] = i + i;
    }
    /*
    // clflush all probe array
    for(int i = 0; i < 256 * 1024; i++){
        printf("i:%d probearray+i:%d\n", i, *(probe_array + i));
    }
    */
    long res;

    uint32_t * ptr = &probe_array[0];
    /*
    // flush probe array
    for(int i = 0; i < 256 * 1024; i++){
        asm volatile(
            "clflush %[mem]"
            // out
            :
            // in
            //:[mem]"rm"((uint32_t*) (probe_array + i))
            //:[mem] "rm"(probe_array) // this works
            :[mem]"rm"(&probe_array[0]) // this also works
            //: [mem]"rm"(&probe_array[2]) // why this is not working?
            //:[mem]"rm"(ptr)
        );
        //*ptr++;
    }
    */

    asm volatile(
        "clflush %0"
        // out
        :
        // in
        //:[mem]"rm"((uint32_t*) (probe_array + i))
        //:[mem] "rm"(probe_array) // this works
        :[mem]"rm"((uint64_t)&probe_array[1]) // this also works
        //: [mem]"rm"(&probe_array[2]) // why this is not working?
        //:[mem]"rm"(ptr)
        //: "rm"(&probe_array[1])
    );

    register uint64_t delta;


    asm volatile(
        // start timer
        "rdtscp\n"
        // move counter to the r10
        "mov %%rax, %%r10\n"
        // try to read first element of probe array to the eax
        "movl %[mem], %%eax\n"
        // read the timer again
        "rdtscp;\n"
        // find the difference between measurements
        "sub %%r10, %%rax\n"
        "mov %%rax, %[delta]"
        // output
        : [delta]"=a"(delta)
        // input
        : [mem]"rm"(&probe_array[0])
    );

    printf("delta1:%ld\n", delta);

    asm volatile(
        // start timer
        "rdtscp\n"
        // move counter to the r10
        "mov %%rax, %%r10\n"
        // try to read first element of probe array to the eax
        "movl %[mem], %%eax\n"
        // read the timer again
        "rdtscp;\n"
        // find the difference between measurements
        "sub %%r10, %%rax\n"
        "mov %%rax, %[delta]"
        // output
        : [delta]"=a"(delta)
        // input
        : [mem]"rm"(&probe_array[0])
    );

    printf("delta2:%ld\n", delta);


    /*
    // measure access time
    // to make sure clflush is working
    register uint64_t delta;
    ptr = &probe_array[0];

    for(int i = 0; i < 256 * 1024; i++)
    {
        asm volatile(
            // start timer
            "rdtscp\n"
            // move counter to the r10
            "mov %%rax, %%r10\n"
            // try to read first element of probe array to the eax
            "movl %[mem], %%eax\n"
            // read the timer again
            "rdtscp;\n"
            // find the difference between measurements
            "sub %%r10, %%rax\n"
            "mov %%rax, %[delta]"
            // output
            : [delta]"=a"(delta)
            // input
            : [mem]"rm"(ptr)
        );
        *ptr++;
        if( i < 10)
        printf("i:%d, delta:%ld\n", i, delta);
    }
    */
    /**
     * Working example.
      
    for(int i = 0; i < 256; i++){

        
        asm volatile(
            //"clflush %[mem]"
            "mov %[mem], %[res]"
            // output, none
            : [res]"=a"(res)
            // input
            : [mem]"rm"((uint32_t*) *(probe_array + i))
        );
        if(i == 16 || i == 0)
            printf("i:%d res:%ld\n", i, res);
    }
    */
   /*
    if(childpid = fork()){
        printf("I am if forked\n");
    }
    else{
        sleep(2.0);
        printf("I am else forked\n");
        wait(NULL);
        printf("Child has terminated\n");
    }
    */
    return 0;
}