#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include <unistd.h> 
#include <sys/wait.h>
#include <malloc.h>
// kernel start location
// if there is no KASLR
#define PHYS_OFFSET 0xFFFF880000000000ul

int main()
{
    int childpid;

    uint32_t * probe_array = (uint32_t *) memalign(4096, 256 * 1024 * sizeof(uint32_t));
    
    // memset the whole array
    // fill with 0's
    //memset(probe_array, 0, 256 * 1024 * sizeof(uint32_t));
    
    for(int i = 0; i < 256 * 1024; i++){
        probe_array[i] = i + i;
    }

    long res;

    // flush probe array
    for(int i = 0; i < 256 * 1024; i++){
        asm volatile(
            "clflush %[mem]"
            // out
            :
            // in
            //:[mem]"rm"((uint32_t*) (probe_array + i))
            //:[mem] "rm"(probe_array) // this works
            :[mem]"rm"(&probe_array[0]) // this also works
            //: [mem]"rm"(&probe_array[2]) // why this is not working?
        );
    }
    

    /**
     * Working example.
     */ 
    for(int i = 0; i < 256; i++){

        asm volatile(
            //"clflush %[mem]"
            "mov %[mem], %[res]"
            // output, none
            : [res]"=a"(res)
            // input
            : [mem]"rm"((uint32_t*) *(probe_array + i))
        );
        if(i == 16 || i == 0)
            printf("i:%d res:%ld\n", i, res);
    }
    
    return 0;
}
